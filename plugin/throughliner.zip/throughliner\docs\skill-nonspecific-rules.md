---
name: skill-nonspecific-rules
docset: current
note: >
  The rules that fire whatever is running. Extracted from the retired
  plugin-behaviour.md on 2026-08-10; skill-specific rules went down into the
  doc for the skill that uses them.
  Register: structure in typed blocks, everything else in prose, tags inline.
---

# Throughliner — skill-nonspecific rules

**A rule belongs in this file only if it fires in all four skills — /setup, /plan,
/next and /done — or in conversation with no skill running.** A rule that fires
inside one of them belongs in that skill's own doc, where it is paid only when
that skill runs. This test is what the filename states, and it is the admission
control: check a candidate rule against the four, and against the no-skill case,
before writing it here. The last limb exists because this file is the only thing
loaded when nothing is running, so a rule wider than any skill would otherwise
fail the test for being too general rather than too narrow.

**A rule in this file is written as a bullet, as a paragraph whose bold leads the
line, or as a line inside a typed block** — the three shapes this file already
uses throughout. Anything else is a defect at authoring time.

Active in every chat where the plugin is installed and the project is set up.
/setup is the one skill that also runs *before* that point — adopting a fresh
folder — and these rules are not loaded there; they govern its migration and
top-up runs, which happen in projects already set up.

## What the method is for

Orientation, read here; it is not recited to the user.

```
The point, carried by every session whether or not a skill is running:
  1. The user's intent keeps running the project whatever Claude remembers.
     The reasoning travels as prose — capture, work item, record — so a
     fresh session builds what the user meant instead of guessing from code.
  2. Approving is what makes the record the user's, and so trustworthy —
     it happens in conversation, in plain words, and the record is what
     that conversation produces.
  3. Settled things stay settled: a rejected option carries why it lost,
     so it is not proposed again and decisions are not relitigated.
  4. Recorded intent is what makes drift visible — a contradiction can only
     be caught against something written down.
```

## The work cycle

Orientation, read here; it is not recited to the user.

```
The work cycle. Every piece of work travels the same loop.
  WHO RUNS THESE — the user types every command. Claude names the one
     that fits and hands it over.
  STANDING — anything noticed, by anyone, at any moment, becomes a
     capture in Unprocessed. Not a stage: it is available throughout.
     Any chat may file one; only /plan may process one.
  1. /plan — think and organise. Processes a capture: kept into
     Processed, or deleted. Keeping settles how it runs — build,
     [audit], [user], [freeform] — and where it sits.
     Processing a capture is also how HELD work blocked by
     another item is released: process the item that blocks it.
     Where nothing in the queue blocks it yet, file the blocker
     as a capture first, then hold the item against it. Work
     held by a DATE releases itself — nothing is processed and
     nobody confirms it.
  2. /next — build. Takes the top piece of ready work from above the
     readiness line and builds it, top-down, several back-to-back.
  3. /done — record what happened, and commit.
  4. Then the chat ends and a fresh one starts, carrying no memory of
     this one. Every return edge below therefore routes through a FILE.
  5. RETURN EDGE — an [audit] edits nothing. It files findings as
     captures, which re-enter at the standing step and become work at
     step 1.
  6. RETURN EDGE — a build that discovers something files a capture and
     carries on. The discovery re-enters at the standing step.
  7. [user] work is walked through, never built. It leaves the loop only
     when the user has done it.
```

## Communication

- Write in plain language, using a term of art only after the user has used it.
- Say so where an approach is wrong, rather than agreeing.
- Run every command you can run yourself, handing one over only in the cases the
  rules below name.
- **Name the method's own command in words and ask the user to type it** —
  `/setup`, `/plan`, `/next`, `/rescan` and `/done` are theirs to run, and the
  scope-lock refuses an attempt to invoke one. Where a command the user typed
  arrived as ordinary chat text, say it likely had not registered yet and ask
  them to type it again.
- **Name the environment a step needs and let the user say whether it fits** —
  "This step needs a terminal open separately from the app, do you have one?"
  rather than "Run this in your terminal:". Users here are non-coders who may
  never open a terminal.
- **Shape every message the same way:**
  - leading with the decision — the one thing the user must see or act on —
    with reasoning and alternatives offered on request, not front-loaded;
  - rendering the single user-facing ask in bold, phrased as a question, at
    the end of the message — naming any command it offers in words rather than
    as a slash string, and keeping that command clear of the sentence's end, since
    the app lifts a trailing slash command into the composer where one
    keystroke sends it;
  - giving one item per message when the user's next action depends on the
    prior one, per `[SEQUENCE]` below — in every multi-part exchange, inside
    skills and out, with no exemption for items that seem short;
  - folding what several checks turn up into one narration, with anything the
    user must act on leaving the bundle and going on its own;
  - speaking between tool calls for the first call, a load-bearing finding, or
    a change of direction, and closing with the outcome first;
  - saying what the user needs in order to act, in full sentences, and
    stopping there — except that where being readable and being short pull
    apart, readable wins.

  **The inversion governs sequencing; approval-before-write is a separate
  axis.** Write-first answers *show-then-wait or write-then-report*, and its
  test is recoverability; the inversion answers *one item per message or all
  together*. An inversion delivers a set in one message, and writes still
  proceed without waiting for approval.

  ```
  inversions — deliver together, not one at a time:
      alternatives the user is choosing between   # the choice is between them
      a deterministic result set under approved
      criteria                                    # bulk approval; contested
                                                  # items then go one at a time
  NOT an inversion: [user] walk-through items     # driven live, always sequential
  NOT an inversion: an audit's findings           # filed straight to Unprocessed,
                                                  # nothing waits for approval
  ```

- **Where the user directly asks for something now and a rule of this method
  would hold it back, warn once and then do it.** One standalone turn naming
  what the request crosses, what the risk is, and — briefly — what could be done
  instead; the work then commences on their next word, whatever that word is.
  Both the warning and the work go into the session's record. Subject to the
  approval rule for anything that leaves the machine, and to the file-safety
  rules for destruction git cannot undo — in those two the existing gate stands
  and the request does not carry through it.

  **The warning is a turn of its own, so the request can be withdrawn.** Warning
  and complying in one message leaves nothing to withdraw, which is the user's
  reason for splitting them.

  **Asking a second time is not what unlocks this** — one warning, then the
  work. A rule enforced against a direct, repeated request is the failure this
  ends: four asks for one thing, refused each time on a rule the user had
  already heard.

- **When capturing something mid-skill, close by who raised it.** User raised it →
  ask "anything else?" before resuming. Claude noticed it → confirm and resume,
  naming what you filed ("I noticed X, filed it, resuming"), and carry straight
  on. The /plan-time offer for an un-agreed idea lives in plan.md's process-now
  section.
  **A thing the user has already agreed to in this exchange is written without a
  filing question**, in every skill including /plan: report it in one line
  naming what landed, which the user can reject and have reverted. The
  plan-time offer is for un-agreed ideas — agreement is the answer the offer
  exists to get, so asking for it again after it was given is the over-asking
  this method removes. Delete asks, send asks and the process-now offer are untouched:
  those decide something other than whether to file.
- **A verbatim-copy string is a paste target, and paste targets are rendered by
  the View-in-doc rendering section below.** Scope: genuine paste targets only —
  paste-ready prompts, and commands the user runs in a separate terminal. Commit
  messages are not paste targets (Claude runs the commit). Two paste targets
  belonging to the same approval go under a single approval in one message.
- **Write first, then report — decided by one test: is the previous version
  recoverable without the user's help?** Consent happens in conversation, in
  plain words, before the write.

  **While a design or a disposition is still being worked out, offer to capture
  and hold the write until the user says go.** The test above is untouched; this
  names when the text counts as finished. It covers ideation in any skill and the
  processing of captures in /plan alike.

```
YES -> write it, then report      queue items and captures · LOG entries ·
                                  SPEC edits · ordinary file edits in a build
NO  -> show it, then wait         a commit message · anything that LEAVES THE
                                  MACHINE (the feedback report, an outbound
                                  INBOX message to another project) · a
                                  wholesale conversion of a document the user
                                  already owns, where git does not yet hold it
EXCEPTION                         a close-time or /rescan candidate set —
                                  several ideas landing at once at the
                                  session's end — is shown as ONE numbered
                                  message before anything is written; the
                                  user contests by number
```

  **An untracked doc answers the test with a no, so its writes are show-first.**
  Where `SPEC.md`, `QUEUE.md` or `LOG/` is gitignored — a configuration /setup
  offers — git holds no previous version, so nothing can be reverted without the
  user's help. This is the existing test applied to a fact it can now read, not a
  new rule: session_start reports which of the three are untracked at every
  opening. Two further consequences are stated rather than repaired: a deleted
  queue item is genuinely gone, and the close cannot read its own work back from
  the file's history, so it records from what it remembers.

- **Show-first, on request.** The user can ask to see doc-resident text before
  it is written, for the rest of the chat.

```
scope:     doc-resident writes — queue items, captures, LOG entries, SPEC edits
trigger:   the user asks. Nothing detects it; there is no stored setting.
effect:    show the text, wait, then write — for this chat only
floor:     the show-first cases above stay show-first regardless. The switch
           moves in ONE direction, toward more showing.
```

  Held in the chat only — nothing is stored.

  **Being driven remotely is not a separate trigger.** It is a case where the
  user asks. No detection is built to reach an outcome that asking reaches.

  **The report after the write is one line** naming what landed and where, and
  pointing the user at the artifact to read — never a re-paste of the text just
  written. **Name the artifact
  specifically enough that the user knows which one to open**, and say they can
  reject what is in it and have it reverted.

  **The report is a pointer to the record; the user reads and approves the
  record itself.** What keeps the reading affordable is the artifact's own
  length, not a longer report.
- **When text IS shown — the show-first cases above — the View-in-doc rendering
  section below says how.** End the message with an explicit ask naming the
  decision needed.
- **Offer a fresh-chat handoff when the user reports the chat degrading.**
  You have no gauge of context filling — the trigger is always the user's report
  ("this is getting long", "you're making more mistakes"). Then offer both: to
  continue in a fresh chat, and to write a paste-ready handoff prompt carrying
  the state forward. Name both — a non-coder won't know either is possible. Fires
  wherever the user gives the signal, in plain conversation as much as inside a
  command.

### Ignore stale setting fields from older setups

A project's CLAUDE.md may still carry an `Editor:`, `Working mode:` or
`Completion mode:` line — all three settings are retired. Leave the line where it
is and carry on as though it were absent: the project is a normal one.

### View-in-doc rendering

The canonical rule for how doc-bound text is rendered — including the blockquote
form for shown text and the fence for paste targets, both stated above and
governed here. Other docs point here.

**The render rule keys on doc-residency, and nothing else:**

```
text NOT yet written              ->  inline
    # the show-first cases only: a commit message, an off-machine send.
    # Nothing exists to point at yet.

text already doc-resident         ->  a plain link to the file, named in one line
    # existing queue items; a capture or LOG entry after its Write succeeded.
    # Under write-first this is the ordinary case, not the exception.

readable edit's post-write reveal ->  a plain link to the file, with the line
                                      named in the prose ("around line 40")
                                   ->  an inline excerpt if the link won't resolve
```

**Link the file plainly and name the line in the prose**, since the desktop app
opens `.md` in its own viewer and silently ignores a link's anchor.

**How inline text is formed, whichever rule sent it there:**

```
shown text (the show-first cases)  ->  a blockquote with a bold lead-in naming
                                       the content type (**Commit message:**,
                                       **Report draft:**)
a paste target, or content whose   ->  a fenced code block, one string per
  exact characters ARE the             fence — the app's copy takes the whole
  substance (code, shell commands)     message
structured explanation shown to    ->  one item per line, never aligned
  the user                             columns — a column wraps into nonsense
                                       at the user's width
```

**Pointing is unconditional — there is no user override.** The reader away from
the file is served by the plain-English summary that opens each item's
discussion; seeing exact wording means opening the file.

**Write, then verify, then point — in that order.** A pointer to content written
this turn goes out only after the Write returned success *and* a re-read confirms
the content is there. (Pointing at text that already existed carries no write to
confirm — there the re-read is just a resolves-check.)

### Vocabulary — one test

**Is the term being used in passing, or explained?**

```
in passing        ->  translate or omit: "the loop" -> "the next item";
                      "Step 2 comes next" -> say what happens next, or
                      just do it. Typically: loop · Step N · Phase X ·
                      sub-step · pass · gate · pre-flight · response-shape
                      tag names · procedure-doc filenames · hash backfill ·
                      queue-lint flag · general developer and testing
                      vocabulary — any term naming nothing in the user's own
                      files (specimen: "fixture")
explained          ->  use it, and explain it once. Where the term names
                      something you can show — a line in a file, an entry in
                      the queue — showing it is usually the shortest
                      explanation there is.
a queue item named ->  lead with its heading's opening words — what the
  in output            outline shows — and put the slug after them. On its
                      first appearance in each message, say what the item is
                      FOR where the heading doesn't already carry it. Per
                      message, not per chat — a reader is not holding the
                      scrollback. Output only; inside queue prose a slug
                      stays bare.
```

**The method's own terms are the vocabulary spoken with the user — the words its
artifacts and commands actually show: capture, work item, Processed,
Unprocessed, cleared to run, red flag, `[user]` item, walkthrough.** Each is
explained once, on first need, and then used. **No plain-English alias is minted
for something the method already names**: an alias is a second name for one
thing, so the user has to learn both and hold the mapping, and the corpus was
growing names faster than any session could translate them. The translate-away
arm above is unchanged — it covers internal mechanics the user's files never
show, which is a different case entirely.

**Text written at a halt or stop — where the user must decide rather than
follow along — states the situation in terms needing no method vocabulary.**
The explained arm does not apply there: a halt is the moment the user has least
context for a new term, and explaining one mid-alarm buries the decision under
the vocabulary lesson.

**Where the user is asking about the procedure itself, name its parts and
explain each term once.** A term that names nothing in their world can still earn
one explanation, because the alternative is a longer sentence in its place every
time it comes up.

**A "how does this work?" question is answered from the procedure rules; a
"why?" or "what is this for?" question is answered from the FAQ first.** Open
`FAQ/index.md` and use the matching entry where one exists; where none does,
answer honestly from what you can read and say that is what you are doing. For
what the plugin does as a whole, the plugin's README is the reference, and new
features are announced on the project's Discord
(https://discord.gg/Z7ftKnSjR) — the FAQ fills from those announcements, which
is why a young FAQ is short.

**How to explain is yours to judge.** Answer the question you were actually
asked, in the form that answers it.

Quoting an artifact the user co-reads (a queue entry, a draft, a log line) is not
narration — quoted text stays verbatim. Processed and Unprocessed are
*user-facing* structure.

## Two repositories in one project

**A session that brings a second git repository inside the project — a clone, a
fork, a fresh `git init` in a subfolder — says so at that moment, names which
repository holds the method's documents, and puts the root choice to the user**,
recording the answer as the standing visibility line in the project's own
CLAUDE.md. The documents and the code silently living in different repositories
is what this catches, and nothing mechanical can judge which root was intended.

## Operate on the folder the chat opens in

Work on the project folder the chat was opened in and no other, taking that
folder as given rather than scanning outward for a different project or asking
the user which one to work on. A user may keep several independent SI projects
nested under one parent — that's the supported shape.

```
opened folder has no SPEC.md          ->  unadopted; offer /setup FOR THIS FOLDER
opened folder contains nested SI      ->  say so plainly, so the user can open
projects (session_start surfaces it)      the child directly. Work stays on the
                                          opened folder either way.
```

## Response-shape tags

Tags compose. When a tag conflicts with the general pull to explain or elaborate,
**the tag wins**. A step's tag governs the narration emitted between its tool
calls, not only the step's final message.

```
[SILENT]    zero text for this step — no narration, no progress note, no
            after-the-fact summary. The work still happens in full; the tag
            governs output, never effort.
[BRIEF]     one or two sentences, then stop. Structured content the step calls
            for (a list, a fenced block) doesn't count against the limit.
[DISCUSS]   a two-way exchange — tradeoffs, concerns, a recommendation, in short
            turns with the user answering between them. Depth arrives as more
            back-and-forth, never as one longer message. Ends when the step ends.
[PROMPT]    stop and wait for the user's reply. Zero further actions — no tool
            calls, no starting the next step, nothing done "while waiting".
            Confidence about what they'll say is not a reason to skip the wait.
[SEQUENCE]  exactly one item per message, then wait. State the count upfront,
            give the first item, stop — no previewing of later items. Where the
            run has a working file, write the full set to it first, then
            release one at a time.
```

**A step whose shape depends on what it finds tags every arm, and the condition
sits OUTSIDE the brackets:**

```
write:   [SILENT] when clean; [BRIEF] when flagging
never:   [SILENT when clean; BRIEF when flagging]     # prose inside the bracket
never:   [BRIEF, PROMPT in the trigger state]         # a condition worn as a tag
```

**Unlabelled steps:** brief acknowledgment if the user needs to know it happened;
no output if purely internal.

**Precedence:** step-level tags override phase-level. During skill execution,
procedure tags govern; CLAUDE.md communication preferences apply to unlabelled
steps and conversation outside skills.

## Tool use

- For bounded checklists — a known set of files to read, fields to compare,
  strings to grep — use direct tool calls. If you can write the lookups out
  before doing them, do them inline.
- **Ask before spawning a subagent, and name the cost.** A subagent (the Task
  tool, or the deep-research skill, which fans out several at once) can exhaust
  the user's usage for the whole chat in one run. Spawn one only for genuinely open-ended
  exploration too broad to write out as inline lookups — and get a yes first.
- **A plain research request gets inline reading and searching first.** Treat
  "look into X" as a request to Read and Grep directly.

## Research and evidence filing

**Offer readily — the bar is low, since the user can decline.**

**Trigger: what would answer this?** Where the answer is something outside what
you can read — a current version, whether a feature exists, what a config option
does — offer the search. Where it is a choice the user owns, ask them. Take the
answer from one of those two routes rather than from your own confidence, which
is what keeps the trigger a question about the subject rather than a judgment
about your own certainty.

**Where the answer is a date, read a computed field — the session opening's date
line, the queue digest's passed or ahead figures — and where none exists, read
the clock.** Never derive today's date by assumption. Same trigger as the rule
above, on the one subject where your own confidence is least reliable and least
checkable: a wrong date is written into a record, a capture or a hold and reads
exactly like a right one for as long as it stands.

**On a repeat question about the same thing, look up how that specific thing is
taught.** Work out first which part did not land, asking the user where it is not
obvious, and search on that narrow target rather than the whole subject. Choose
from what you can perform in text or point at, taking the shortest source whose
content you can read — captions, an article, a transcript — and read it before
pointing at it. Where neither of you can name the missing part, no lookup helps
and the answer is a different explanation.

**Before offering a search, read `resources/research/index.md` and open any entry
whose subject covers the question, then say what it already answers.** The index
is one line per finding, so this is nearly free. It reaches a finding whose index
line describes the subject; a finding filed under a subject line that does not
match how the question later gets asked is still missed, so this narrows the
duplication rather than closing it.

The residual, named rather than solved: noticing that a question turns on an
external fact is still a noticing. This improves the odds; it does not close the
hole.

**Reach for a CLI tool before handing over a GUI walkthrough.** Two halves, both
must fire: (1) *consider* whether a tool would let you do the task instead of
talking the user through it — OCR, image/PDF conversion, file manipulation, data
extraction often have one; (2) *offer a search* when a suitable tool plausibly
exists but you're unsure which.

Guards: name the candidate tool and what it does before using it; downloads,
commands and device access stay under their existing confirm-first rules.

This rule has a second firing site: the moment work is about to be tagged
`[user]` (the over-tag guard in the Captures flavor rules).

### Where findings and records land — a three-way triage

```
reveals work to do                    ->  capture in QUEUE.md Unprocessed
a finding, or a clean pass            ->  the observing chat's LOG entry
    (no verbatim re-read needed)          # a PASS is a finding, not work
evidence a future chat must           ->  a durable file under resources/
    re-read WORD-FOR-WORD
```

`resources/` holds two things only: research findings at
`resources/research/<topic>.md`, and re-read-later testing evidence under
`resources/testing/`. The default answer to "should this be a durable file?" is
**no** unless the verbatim-re-read test is met.

**File research findings as part of using them**, not only when asked. Threshold:
a finding that informed a decision, or that would have to be redone if lost.
Name the file in chat when it lands, so the filing is visible and checkable, and
**write its line in `resources/research/index.md` in the same move** — one line
carrying the subject it settles and enough of the finding to decide whether to
open it, ending in the filename. A file added without a line is invisible to
every later chat, so the folder grows a write path with no matching read path.

**A research finding that is superseded gains a `Superseded by:` line at the top
of its file, written at the moment it is superseded** — which is the moment
someone already has that file open. Name what supersedes it, and say whether the
whole finding falls or only part of it:

```
**Superseded by: <path or item>** — <what falls, and what still stands>
```

The queue digest reads that line back: any queue entry whose prose names a
superseded research file is flagged, so the correction reaches the decisions
built on it.

**It covers only items that NAME the file, and the check says so where it
reports.** An item scoped on a finding it never cites is not reached. State that
whenever this is described; partial coverage read as complete is the failure
this project guards hardest against.

### Temporary files and working artifacts

```
temp file the project never keeps  ->  the session scratchpad directory
    # outside the repo, self-clearing. The scope-lock permits scratchpad
    # writes during a build, so this never conflicts with an active scope.
temp file that MUST live in the    ->  the work line states a specific
    project for a while                 delete-time ("delete after the
                                        migration is verified")
```

A file the project genuinely needs to keep isn't a temp file — route it per the
triage above.

## Captures

A capture is one entry appended to QUEUE.md's **Unprocessed** section. It is
not yet a work item: **"work item" names an entry in Processed only** — work
becomes work when /plan has agreed it. Until then it is a capture, or an
unprocessed entry. Capturing is how any chat puts a new idea, discovery
or task into the queue without stopping to work it. Write it, then report what was
filed; include the reasoning, not just what was noticed.

**A capture may be a single line whose only job is to release held work**, and
its content may be no more than what must happen before that work can move. It
is still real work and still passes the ordinary tests; what it does not have to
be is substantial. So a plan run holding work back and finding nothing in the
queue to name as its blocker writes one.

**Line format — write an entry in this exact shape**, which is what the hooks
parse. The `#### ` heading is load-bearing: the queue lint, the red-flag scan and
the section keying all key on it, and each fails silently against any other
shape.

```
#### <one-line description> [slug]
<prose rationale — the reasoning, in plain short sentences>
Red flag · State: <cleared | uncleared>        # only if it carries one
Runs alone                                     # only if the work moves paths
                                               # underneath a run in flight
Blocked by: [slug], [slug]                     # one OR MORE slugs; lifts only
                                               # when every one resolves.
                                               # Available in EITHER section,
                                               # meaning something different in
                                               # each — see below. Below the
                                               # cleared-to-run line one of it
                                               # or `Not before:` is required
Not before: YYYY-MM-DD                         # a date. Available in EITHER
                                               # section, meaning something
                                               # different in each — see below.
                                               # It lifts itself
```

**A date holds an item on its own, with no blocker item standing in for it.**
Every other blocker needs a human or a build to resolve, which is why blockers
are queue items — a date resolves itself and is read off the calendar by the
hooks, so nobody confirms anything and no wake-up capture is filed.

**`Blocked by:` means one thing on a work item and another on a capture:**

```
on a work item (Processed)  ->  do not BUILD this until every named item
                                resolves
on a capture (Unprocessed)  ->  do not OFFER this again while any named item
                                is still open
```

**On a capture it needs no approval, unlike a date**, because the queue can
check it: the blocker is an entry anyone can look up, so a capture held this way
returns by itself the moment the thing it waits on is processed or built. The
date form is the one that guesses, which is why that one is the user's call.

**`Not before:` means one thing on a work item and another on a capture:**

```
on a work item (Processed)  ->  do not BUILD this before the date
on a capture (Unprocessed)  ->  do not OFFER this again before the date
```

**A capture carries one only with the user's approval, and only where it waits on
something outside the project entirely** — another project's reply, a feature
shipping in a tool nobody here controls. Such a capture can name no blocker,
because nothing in the queue can do what it waits for, and it cannot be held below
the cleared-to-run line either, since being held there requires work specific
enough to build. Without the date it returns to the top of the queue every session
and is set aside again.

**It stays a capture throughout and gains no state of its own.** Two sections and
one readiness line, unchanged — this is one existing field appearing in one more
place.

**Write `Blocked by:` plain, not bolded.** The lint tolerates the emphasis, but
the plain form is what this block shows.

**Put a heading's distinguishing words first**, because the queue is read through
an outline of headings that truncates each one mid-phrase, so the end of the line
may never be seen. This governs word order alone.

The user-credit and the filing-time commit stamp are prose conventions written
into the rationale, not fixed lines of this block — see the two bullets below.

- Slugs are for LOG traceability, nothing more.
- **Provenance is asymmetric and default-AI.** Leave Claude's own work unmarked,
  since an unmarked item reads as Claude's. A convention, not a lint-checked
  field.

  **Two different claims travel under provenance, and only one is about
  wording:**

```
an ORIGIN claim   "captured by you", "you raised this", "on your
                  instruction"
                  -> says where the item came from. Write it wherever
                     the user raised the thing, and state it in your own
                     paraphrase. No quotation is required or expected.

a QUOTE claim     "your words", "in her own words", quotation marks
                  -> says how something was phrased. Write it only over
                     text the user actually said, reproduced verbatim.
```

  **Write an origin claim wherever the user raised the item, whether or not
  their wording survives.** Everything in these documents is written and
  recorded by Claude, so requiring a quote for an origin claim would move every
  un-transcribed idea of theirs into Claude's column — and the cheapest way to
  satisfy such a rule is to ask the user to prove their own work is theirs.

  **Reserve a quote claim for verbatim text**, so a point rendered in Claude's
  own words is framed as Claude's rendering of it. Quotation marks around a
  paraphrase satisfy nothing here.

  **Approval is not authorship, for either claim.** Agreeing to a proposal
  Claude reasoned out makes the reasoning Claude's. When in doubt about origin,
  leave the item unmarked, which reads as Claude's.

  **The containment test tells agreement from authorship: a reply wholly
  contained in Claude's preceding message cannot evidence an origin claim.**
  Without it the rule above has no way to judge a one-word answer — and a
  one-word answer is often a tap on a suggested reply, which is Claude's own
  wording returned. Where the reply adds nothing Claude did not just write, the
  decision is Claude's and the item stays unmarked.

  **Existing credits are not audited in bulk, and not disclaimed in bulk
  either.** The test needs the message that preceded each credit, which is not
  recoverable item by item. Declaring past credits unreliable wholesale would be
  an unverifiable claim about the record that degrades every honest credit
  alongside the doubtful ones. Check a specific credit when it is challenged.

  **Mixed authorship is written as mixed**, naming who did which part — *"Bundling
  by hand was rejected on Claude's recommendation and the user's agreement."*

  **The same split binds reason-shaped sentences inside the prose** — "their
  reason", "the user's call", "on their instruction" are origin claims about a
  reason, so write one where the user gave that reason and quote it only where
  you are reproducing how they put it.

  **In a session holding more than one person, credit attaches to the named
  person whose message raised the item** — an origin claim names them ("raised
  by <name>") exactly as "captured by you" does with one person in the room,
  which is the case the general wording contains. **The containment test runs
  per person**: a reply wholly contained in Claude's preceding message
  evidences no origin claim, whoever sent it, and agreement is not authorship
  for any participant. **Identity is the authenticated identity the channel
  supplies where the channel authenticates its members** — a role attesting a
  real login; where it does not, a named person's word is the fallback and is
  read as such. **A session roster carries only details a participant has
  chosen to share**, and the scrub checklist reads it: a detail not on the
  roster is rewritten away like any other personal detail — the published-
  identity arm for third parties on GitHub is unchanged.
- The **filing-time commit stamp** exists because a capture filed after a
  chat's /done close belongs to no committed session record. Plain prose, not
  a parsed field.

**Flavor marker** — an optional leading tag naming how the item is executed:

```
(no tag)     ->  build   ->  /next routes to next-build.md
[audit]      ->  review  ->  /next routes to next-audit.md; findings become captures
[user]       ->  walk-through; /next walks the user through it, never builds it
[freeform]   ->  work done by hand rather than by /next; /next halts on it
```

The tag **leads** the description. One leading tag at most. Flavor is settled
when the item moves into Processed.

**A flavor names how a work item is executed, and `[freeform]` is a flavor like
the rest, not a mode a session is in.** Hand-work in a chat with no queue item
behind it has no name and needs none.

The `[user]` tag is governed by a **matched pair** of rules. Both failures are
real and equally bad; neither warning may be louder than the other. (How a
`[user]` item is then *run* is the walk-through lifecycle in next.md.)

- **Reserve `[user]` for work Claude genuinely cannot perform or witness** — a
  check needing the user's eyes, a decision only they can make, a physical
  action. Work Claude *can* run but can't run *yet* (blocked on a push or
  restart) is an **ordering** concern: file the thing it waits on as its own
  queue item, and place this one below the cleared-to-run line naming that item
  as its blocker. The test is "can Claude do this at all?", not "can Claude do
  this right now?".

  **And the test is a check, not a judgment: before tagging `[user]`, ask what
  would answer this — name the tool that would do the work, and confirm it is
  absent or unauthenticated.** Where no tool plausibly exists, that is itself
  the answer. It runs thorough at /plan's decision step and light at /next's
  pre-hand-off; each doc carries its own weight.
- **File every piece of genuine user work as a `[user]` item**, so it lives in
  the queue rather than in the conversation, which ends and takes it with it.
  When "can Claude do this at all?" returns **no**, file it. A thing in the
  world an item waits on is filed as its own item in Unprocessed, and filing it
  is where the user's part gets its `[user]` item.
- **Where an item's own record shows it was handed to the user for completion
  after a close, and it names no observable this method can reach, ask once
  where the work landed instead of re-driving it.** Both facts together, read
  off the record: a hand-over recorded at a close, and no reachable observable.
  An item without a recorded hand-over never qualifies, and neither does one
  naming something checkable. One ask, then take the answer.

  This is an exception to the completion-ask bar below, and it exists because
  the bar cannot be restated to cover the case: all three routes it leaves open
  — walked to its end this session, the user volunteers it, an observable check
  passes — are shut by construction here. The work happened in a chat that
  closed, so nobody can walk it; there is nothing in the world to check; and the
  one remaining route asks the user to remember an item they were handed days
  ago. Without the ask the item is re-presented as unstarted, which is the
  failure this admits it for.

- **Walk a `[user]` item through whenever it is reached, and learn completion
  from what the user volunteers.** That is its whole lifecycle in every skill —
  /plan, /next and /done alike. A filed `[user]` item may be walked the moment
  it is filed, with the user present, where walking it now clears a red flag or
  unblocks work this session is doing; the item is written into the queue before
  its first step is driven, so an interrupted walk survives there. Before walking,
  list `LOG/` for records under the item's slug and read any found; say which
  steps the record shows done, and resume at the first that is not. Where the
  item names an observable result, check
  the world for it: a file present or absent, a branch gone, a URL responding.
  Where it names none, the item stays in place until the user mentions it.
- **A `[user]` item carries a walkthrough** — which steps, in what order, what to
  check. **Each step names the thing to click or type and the thing to look for**,
  so "Open your session list" becomes what to click to get there and what tells
  you it worked. Every consumer of this method is a non-coder, and most will not
  have used the surface a walkthrough names, so a step assuming familiarity is
  under-specified for the whole audience rather than for one person. This fires
  at authoring time, where the cost is wording, and stays there — the decision step
  and the hand-off ask no per-item question about whether the user can perform a
  step. **Where the steps cannot be fully scripted yet, file the item with a
  rough walkthrough flagged for refinement at the decision step.** The one thing that
  keeps work out of a `[user]` item is genuine uncertainty that it is user-work
  at all, and that routes to Unprocessed as an ordinary capture, still tracked.
  Two further requirements on the same walkthrough:
  - where it involves more than one stored text — a pinned message, a forum
    post, a register line — naming where each one lives, since a step saying
    "update the text" is unfollowable once there are two of them;
  - where a step verifies something, listing the claims it checks, so the user
    knows what a pass covered rather than only that it passed;
  - ending at the item's own observable, with cleanup after the test filed as
    its own item rather than written as trailing steps — a walkthrough that
    carries on past the thing it was proving has no point anyone can check it
    against.

The `[freeform]` tag names **work done by hand rather than by /next** — because it
is large, or because it characteristically cannot run inside a run. Its main job
is telling the close what kind of work it is looking at. **Before its first
edit, a freeform session working a queued item writes a scope file —
`_freeform-<session-id>.md` in the project root, with a `Files:` section
listing the paths the item's instructions name — and reports it in one line.**
The safety check reads that file and permits the listed paths for this session;
without it, edits outside the standing planning surface are refused.

**Most freeform work never passes through /plan at all.** The user and Claude do
it by hand in a chat of its own, and /done reads the resulting edits as their
expected work. Where one *is* filed as a queue item, it is ready work with nothing
blocking it, so it sits **above** the cleared-to-run line and /next halts on it;
the tag carries that exception rather than a third region of the queue.

A repair to the machinery /next itself uses — the queue mover, the scope-lock, the
lint — is **one example** of work that cannot run inside a run, since running the
broken mechanism to build past it is the failure. It is an example and not the
definition.

### Scrub before writing, and state the limit

**When filing a capture, read what you're about to write against this list**
(/plan runs it again at the decision step and /done when writing a LOG entry — each
says so where it applies):

```
personal names (the user's collaborators, clients, anyone not in the room) —
    except that a third person is referred to by the identity they have
    published on GitHub: username, pronouns where supplied, first name only
    where they put it there. Anything they have not published is rewritten
    away like any other personal detail.
case or matter details that identify a real situation
third-party data of any kind
credentials, keys, tokens
file paths that identify a person or an organisation
```

Rewrite what you find, at the same level of usefulness — "a family member",
"the client's deadline" — rather than dropping the fact. **An additional pass is
available: `scripts/scrub_sweep.py` under the plugin root sweeps for the same
shapes** — run it alongside the read, which stays: the script matches shapes,
and the read is what catches a sentence that quietly identifies someone.

**State the limit whenever this comes up.** This checklist is Claude checking its
own writing, and the hook's scan matches credential *shapes* only. Neither can
tell whether a sentence quietly identifies a real person. **So describe the
artifacts as checked against those two things and no more**, and where a user
asks whether their repo is safe to make public, say that not publishing these
artifacts is the only real protection.

**Authoring standard — one provision, two scopes.** Plain short sentences, one
idea per sentence, whichever is being written. The human co-reads and approves
this text: **unreadable is unapprovable.**

```
the RECORD — a capture, a queue item, a LOG entry, a SPEC edit
    keep the facts, references, conditions and reasoning that led here.

a DELIVERABLE written to disk — a report, a summary, a document for a reader
    its length matches what the task needs. Out comes a filler section, a
    summary of what the document already said, boilerplate.
```

**Every written shape is bounded, and this is the one statement of it — every
other length rule in the method is subject to this one.** Three provisions:

- a record — a capture, a queue item, a session entry — is bounded by the median
  of its own shape in this project's measured distribution;
- a deliverable written to disk is bounded by what the task needs;
- an index line is bounded by the median index line, per Index entries below.

**Read the bound off the corpus:** `scripts/
measure_written_shape_length.py` prints each shape's current median. A median is
a proportion of what is already written rather than an invented figure, and it
ratchets — writing to it pulls it down.

Both failures are real: a record too thin to rebuild intent from fails as surely
as one too long to get through, and the second is what this method has produced
at scale.

**A plan entry splits per item processed, exactly as a build entry splits per
item built.** A planning decision is a disposition on a queue item, and that item
carries a slug, a filename and an index line. What is genuinely chat-level — a
correction given, an error found and fixed, a decision belonging to no item —
goes in the `Also in this chat:` section.

**The lever is where text lives as much as how much of it there is.** A work item
is divided into the instructions a build reads and the decision history a person
reads; history is relocated to the record and cited from the item rather than
carried inside it.

**Run `<plugin-root>/scripts/measure_written_shape_length.py .` to report this
project's own distributions.** It prints how long your captures, work items,
session records and index lines actually run, and it prints no threshold of any
kind — the same posture the queue digest and the growth reports take: state the
fact alone.

**Placement: append to the bottom of Unprocessed, always.** No judgment call, no
narration line. **A capture filed mid-run follows the same rule and gets no
special priority.**

**File it with the queue tool**, the way a move uses it: write the entry's text
to the session scratchpad with the editing tools, then

```
python <plugin-root>/scripts/reorder_queue.py <QUEUE.md path> \
    --append Unprocessed --body <scratchpad path>
```

**Subordinate to the ideation loop above** — this is what runs once the loop
releases the write.

**Narration discipline.** State what was filed in one line and move on, leaving
the shelving mechanics unsaid. Put timing in the capture-now, design-later frame
("filed for a later /plan").

**Reference other queue items by slug**, leaving status out of the sentence:
status is re-derived from LOG, and an asserted one goes stale silently. A slug
written into prose is also the only thing that makes a cross-reference exist at
all, and it stays grep-able through any reorder.

## Queue states — the canonical four

The lifecycle of an entry in QUEUE.md, from capture to work. **It is a model of
queue states, not of work-item states**, because the first of the four is not a
work item at all: an entry becomes a work item when it reaches Processed.

```
Unprocessed                    a capture, not yet fully processed. Two kinds:
                               never-discussed captures, AND work discussed and
                               worth doing but not yet designed enough to say
                               what its build would change.
Processed, above the line      a work item, kept and ready. /next picks work
                               from here, except a `[freeform]` item, which it
                               halts on.
Processed, below the line      a work item, designed and buildable, held by a
                               named queue item or by a date — and by nothing
                               else.
Deleted                        judged not worth doing. Git history keeps it.

discriminator: can you describe what gets built?
    no                        -> Unprocessed
    yes, and something holds  -> Processed below the line, naming its blocker
      it                         or its date
    yes, nothing holds it     -> Processed above the line
```

**An empty Processed section is normal** — the vetted work is done.

**One shelf, one shelving move: not-ready work goes to the bottom of
Unprocessed, and that is the only defer.** It covers every "set this aside" case
— a fresh capture, an unclearable red-flag capture, a /plan skip-to-defer.
Resolve any pull toward a new state, tag, shelving category, or a "focused chat
of its own" by recommending skip-to-defer, or by giving a queue-shaped thing that
isn't work its proper home below.

**A fate the user has already decided stays closed through routing.** Where an
item's own prose records that the user asked for something to be kept, the
routing question is closed before it starts — the table below is for things
that have no home yet, and work whose fate is settled keeps it.

**Proper homes for queue-shaped things that aren't work. Decide by what the
thing IS:**

```
a principle that governs how work is done  ->  SPEC note, or CLAUDE.md rule
    ("always consider X when designing")
a durable finding                          ->  resources/research, or LOG
a forward recommendation                   ->  the advisory (transient)
```

The cleared-to-run line **replaces** parking. Order within a section carries
build order and processing order; a *blocking* relationship is carried by the
`Blocked by:` field — on a work item, work that cannot be built until other work
ships; on a capture, an idea not worth offering again while the named entry is
open — and carrying an ordering preference instead by placement plus one
sentence in the item's prose naming what it should follow. **The field takes
several slugs where the work waits on a group, and the item lifts only when
every one of them resolves** — a single proxy blocker would report it liftable
the moment that one item shipped, with the rest outstanding, and the revisit
trusts the field. `Blocks:` and
`Depends on:` headers stay retired: one field, in one direction, on the item that
is held.

**Carry an ordering preference in prose, because the field would hide the entry.**
On a work item `Blocked by:` sends it below the cleared-to-run line, and on a
capture it makes the ranking pass over it silently — either way out of what the
user sees during an ordinary run — which has
already cost a consumer project two fully designed items and its user's
confidence that a feature was queued at all. A prose sentence survives a reorder,
since the sentence is the relationship and the position is only where it runs.

## Red flags

Screen every chat for anything that could expose the user's data or their
users' data, or amounts to a breach — a duty owed in every chat, and one that
catches only what it spots, so it is never a guarantee that every risk present
has been found. When one is found, state the risk in plain English, surface it
immediately, and tag the queue entry carrying it with the `Red flag · State:`
line shown in the Captures line format above — usually a capture, since an
uncleared flag lives in Unprocessed.

**The flag rides the work** — the item is the work (what will be done about the
risk) and the marker tags it as carrying the concern, so the flags live on items
rather than in a section of their own. A standing "Red flags" section would claim
the tool tracks every risk that exists, when all it holds is the risks Claude
happened to spot: risk-*addressing*, never risk *management*.

Scope: security, privacy and breach risk — data exposure, unauthorized access,
credential handling, injection vectors, information leakage, unprotected storage.
The threshold is a genuine risk, not every data-handling intention. A risk
spotted during planning is flagged the same way, before any code exists —
nothing here is build-only.

**Flagging, not fixing.** Name the risk and route it, leaving the decision with
the user, however obvious the fix looks.

**States and lifecycle:**

```
uncleared  risk stands, unaddressed. Lives on a capture in Unprocessed —
           never in Processed.
cleared    dealt with, one of two ways:
             designed out / fixed        -> LOG records how
             consciously accepted        -> LOG records the informed-consent
               by the user after being      trail: what they were warned about,
               told plainly                 and that they chose to proceed
```

An item reaches Processed only with its flag cleared; a flag that can't be
cleared returns its item to the bottom of Unprocessed. So every risk ends
cleared, or its item is deleted. A marker always sits on an item carrying real
remaining work, and it leaves only when that item does.

/next builds a red-flagged item like any other; the close carries the cleared
flag into the LOG entry. **Backstop:** an uncleared flag in Processed should be
impossible, so if /next or the close meets one, it stops and surfaces it.

## The throughline

**Rationale is prose, and it is carried forward as prose.**

A reason travels capture → processed work → log as prose. At each stage
re-author it to fit context, write it, and report where it landed.
Reasons live inline in the entry text. That travelling reason is the
**throughline**, and it is what the method is named for.

**The throughline is the reasoning spine — the thread of *why* — not any one
file.** Intent lives in SPEC, rationale rides every QUEUE item, history lives in
LOG. SPEC and QUEUE are read during planning and building, so the throughline
shapes work silently rather than only on a "why?" question; LOG is the deep
archive, pulled on demand. **LOG is where the throughline is recorded, and is
not itself the throughline** — the tell that they are distinct is that a
complete LOG can carry no throughline at all, every event recorded with the
reasoning stripped out, which is exactly the failure this fights.

**The provenance rule in Captures governs rationale too, in full** — including
the credit-requires-their-words bar and mixed authorship. Where the user's
reasoning is credited, mark it inline where the rationale lives ("the user's
reason for this: …").

What counts as rationale is broader than the decision's reasoning: it includes a
concern raised and resolved, and an alternative seriously weighed, each carried
with **why it lost**. The intuitive-but-rejected alternative most needs
preserving — without the why-it-lost recorded, a later chat re-proposes it and
relitigates a settled decision.

```
qualifies:      a concern raised and addressed; an alternative seriously weighed
                a decision whose rejected path is the INTUITIVE one — always
doesn't:        a passing mention
```

Three collapse-shapes look reasonable and lose meaning silently, so the carry is
written out against each:

```
keep the whole chain, not a one-line summary   # a summary leaves a label
keep it inline, not in a why-field             # a field breaks the carry, and
                                               # trains authors to write it empty
keep the nuance, not a typed taxonomy          # a taxonomy is never complete, and
   ("UX reason / functionality reason")        # forces nuance into the nearest slot
```

**Retrieve.** When asked why something exists, work the cheapest-first ladder in
Prior decisions below — it is the canonical retrieve order. When the ladder
reaches LOG: search the index files (`LOG/index*.md`) for the subject's words —
their one-line-per-entry shape points to candidates faster than scanning prose
— and open the matched entry's file directly (the index line ends with its
filename). A search only finds lines carrying the words tried, so where it
comes back empty, widen the terms before concluding nothing is recorded. Pre-split entries live in `LOG/log.md` and
`LOG/log-v*.md` — find those by the index line's hash or title. Only fall back to
inferring from code if the whole ladder has nothing.

## Index entries

`LOG/index.md` is **Claude-facing, not user-facing.** It exists so a retrieve can
decide which entry to open without reading every entry's prose. Terseness for
human scannability is not the criterion — **specificity for that open/skip
decision** is.

```
each entry must carry:
    the artifact touched      # which file, doc, section, rule, or area
    the nature of the change  # added/removed/renamed/reframed/tightened, with
                              # enough substance to decide open-or-skip
    the entry's filename      # at the end of the line
```

**The index is split by month — the current month's lines in `LOG/index.md`,
each completed month's in `LOG/index-YYYY-MM.md` — and a targeted retrieve
searches the index files rather than reading them whole**, so the archive can
grow without any single read growing with it. The limit is stated rather than
hidden: a search reaches lines that carry the words searched for, and an entry
indexed under phrasing the search never tries is missed — which whole-reading
did not risk. A planning session's opening still reads, unprompted, the
`LOG/index.md` lines newer than the most recent planning session's record.

**Subject to the Authoring standard's length provision above, the bound here is
the content requirement itself:** an index line carries enough to support the
open/skip decision, and says it without restating the entry. An entry too short
to support that decision fails even at one line; a line that reproduces its
entry fails at any length. This stays a judgment test: no mechanical number
replaces it.

## Scope

**Build scope is the active work's described work** — the changes the work items
call for, and nothing past them. That's the definition, enforced by judgment. Its
mechanical approximation, and how /next derives it, is in next.md.

**The scope-lock covers files, so work governed by the approval rules is
everything that happens away from the filesystem** — a message that leaves the
machine, a post, a decision reached in conversation, a step handed to the user.
Those are held by the approval rules and by nothing mechanical.

## Routing and discipline

- **Route to artifacts, not memory.** If it belongs in SPEC.md, QUEUE.md or LOG/,
  write it there.
- **Memory boundaries.** The project's records belong in the project's docs:
  ideas and discoveries → Unprocessed; design decisions → QUEUE/SPEC; project
  state → the method docs. Memory doesn't travel with the project and the user
  can't read it. Memory stays right for what no project doc owns: user
  preferences, working style, cross-project facts.
  - **Feedback about a behaviour the METHOD produced routes by the three-way
    discriminator**, not to memory — a skill's narration, a step that misfired,
    a rule with a bad outcome. Absorbing it as a preference fixes this one
    session and leaves the defect shipping to everyone else.
  - **A preference no method rule governs stays memory's** — a name, a
    timezone, a tool the user likes.
- **Doc routing — four destinations, two confused lines:**

```
SPEC.md      what the project is (what/who/how/why it exists)
QUEUE.md     what to work on next
LOG/         what happened
CLAUDE.md    how Claude should work on THIS project

SPEC vs CLAUDE.md   =  "what it is" vs "how to work on it"
CLAUDE.md vs memory =  "this project" vs "all projects"
```

  Run this as an active self-check on your *own* routing, not just a flag on the
  user's. The two misroutes to catch: writing product truth into CLAUDE.md when
  it belongs in SPEC, and putting into memory what belongs in CLAUDE.md. When the
  user frames something as a behaviour change ("make Claude always do X") that's
  really product truth ("the app does X"), name it as SPEC content and route it
  there.
- **Executable work lives in the queue as work items.** /next runs the queue
  and only the queue; a side doc of steps is
  invisible to /next and silently falls through. A task mixing Claude-work and
  user moments **decomposes into queue items**: build items for Claude's parts,
  `[user]` items for the user's.

```
a plan of work to be DONE       ->  queue items
a record or finding to be READ  ->  a LOG entry, or a resources/ file
```

- **Leave planning work to /plan.** The boundary is **filing vs
  processing**: filing a capture is open to every chat; processing one —
  moving it into Processed, deciding its fate — is /plan's. One consequence
  worth stating: when the user runs a test and judges its outcome, that judging
  is the test work itself, not planning.
- **A discovery made mid-run — decide by one rule: is it needed to complete the
  work being built?**

```
needed and minor        ->  recommend adding it, and ask
needed and significant  ->  propose splitting
NOT needed              ->  capture and continue    # the common case
                            # INSIDE /plan: an un-agreed idea gets the offer
                            # before the write; an already-agreed thing is
                            # written without a filing question — see
                            # plan.md's process-now section
premise is broken       ->  halt and course-correct
```

  "Capture and continue" means: write it to Unprocessed, report what was filed,
  then close it by who raised it (Communication) — a discovery is Claude-raised.
  The write happens at the moment of noticing, since an unrouted discovery
  survives only in memory.

  **User-only discoveries file as a `[user]` capture, tagged at filing rather
  than left untagged.**
  This also fires **at processing time**: when /plan keeps an item and spots a
  user-only gating action *buried in its rationale prose*, split it out into its
  own `[user]` item with its own slug and reference it by slug from the original.
- **Nothing unrouted survives a chat.** File or drop before close.
- **One build at a time.** While this chat's build working file exists, finish
  that build before starting another.
- **One chat runs /plan and /next as many times as the work needs, one after
  another.** A plan run and a next run are runs of a command inside a
  chat, not the chat itself. Run whichever the user asks for, whatever ran
  before it in the chat. The boundary that binds is filing vs processing,
  stated in the rule above.

  **/done closes the CHAT**, once, when the chat is finished — it records
  everything the chat did, across every plan run and next run in it.

  **Work on a project from one chat at a time**, because a capture filed in one
  chat is invisible to the other and the two disagree about the queue from the
  moment either writes to it. Where a second chat is open on the same project,
  say so and let the user close it or come back to it.

  **What happens to an isolated chat's work at close, which is the case that
  loses work.** The harness makes the worktree and its branch and **never merges
  either back**; at exit it asks keep-or-remove, and remove deletes the worktree
  and the branch with everything in them. So an isolated close commits, then says
  which branch the work is on, that it is not merged, and that "remove" would
  delete it. The merge itself cannot happen there — git refuses to update a branch
  checked out in another working tree — so it is offered at the opening of
  a **main-checkout** chat, where session_start reports worktrees carrying
  unmerged commits. Offer the merge and let the user take it; on a conflict leave the
  branch alone and say the work is safe on it.

## Method problem reports and cross-project INBOX

A problem with the *method itself* or with *Claude Code itself* is not work on
the user's app; route it by the discriminator, then **read
`${CLAUDE_PLUGIN_ROOT}/docs/feedback-and-inbox.md`** for the full procedure
(report format, posting flows, the Claude Code branch's guards, INBOX
mechanics). Fetched on demand — the trigger is a user reporting a problem, or
mail waiting at the chat's opening.

```
the discriminator:  which thing is misbehaving?
    my app       ->  an ordinary capture in my QUEUE
    the method   ->  mail to the plugin's own project where this project's
                     address book records it as a correspondent — same
                     machine, nothing published, and it lands in the queue
                     that would fix it; otherwise a GitHub issue on the
                     plugin's own repository, where `gh` exists and the
                     reporter consents — the offer states plainly that an
                     issue is public under their own account;
                     flintcraft.tech/report otherwise, and wherever they
                     prefer privacy
    Claude Code  ->  a GitHub issue on anthropics/claude-code
    unsure       ->  ask the user which of the three it is
```

**A send or post goes out only after the user has seen the exact text and
given an explicit yes** — feedback reports, GitHub issues, and outbound INBOX
messages alike. Inbound INBOX mail is surfaced by session_start and routed
through the three-way triage, then archived.

**When an inbound message asks a question, a reply is owed: draft it unprompted
once the question has an answer** and put it in front of the user. A defect
report is owed nothing by default. The send stays under the rule above; what
this adds is the offer.

## Dependency ownership

- **Claude owns sequencing within Processed** — the order kept work sits in, and
  what gets built first. Make that call and narrate it, rather than putting it to
  the user. **It does not reach Unprocessed:** a capture is appended to the bottom
  with no judgment and no narration, per the Captures placement rule, and
  Unprocessed's order is re-derived by the ladder at /plan's opening.

  **Most of the queue's order carries no weight, so spend no turns on it.**
  Everything above the readiness line is built by one /next run, so its internal
  order rarely changes anything; Unprocessed is ordered by the ladder at /plan's
  opening, at the moment the order is used. Which of two cleared items goes first
  changes nothing, so it is settled silently. Reorder where something is
  genuinely wrong, and otherwise leave the file recording when things landed.
- **Stable slugs.** Kebab-case, assigned at filing, written at the end of the
  description line, and kept through every reorder and rename. **Write every
  relationship as a slug in prose**, since queue position encodes none.

  **Where an ordering between two entries is already KNOWN, write it into BOTH
  of them.** Opening either one then surfaces it. A capture may also carry
  `Blocked by:`, which stops it being offered while the named entry is open —
  but that is a bow-out, not an ordering, so a known ordering is still written
  into both entries' prose. A relationship written on one side only survives by
  luck: two known orderings in
  one chat were each written once, and one was honoured only because the user
  happened to ask for the other item first.
- **Narrate the ordering work.** Any time you exercise ordering judgment within
  Processed — a non-default placement, a reorder — say why in one short
  sentence, since silent ownership reads as no ownership. An append to
  Unprocessed is unnarrated.
- **The user owns whether an item is kept or deleted**, and whether a build
  expands its scope. With more than one person in the session, those decisions
  — and clearing a red flag, and approving anything that leaves the machine —
  belong to the one person holding execution authority, while filing captures
  stays open to anyone present.

## Reading a whole file before reasoning over it

**Page the whole queue before any queue-wide reasoning, and the same for any
file whose *whole* content the reasoning depends on.** A read that stopped short
is named plainly rather than reasoned from quietly. **Check this at the read rather
than later**, because a truncated read looks like a complete one to whatever
reasons over it, so nothing downstream can detect it.

**A mechanically generated digest satisfies this rule for the fields it computes,
and for nothing else** — code that reads the file end to end cannot be silently
truncated, which makes it stronger than paging *for those fields*, and it says
nothing at all about the prose it omits. So where a skill provides one, run it
**and** read the file: the script gives computed facts, the read gives the
reasoning. A digest is generated from the whole file, by a script; one
assembled by whoever is reading is the partial read this rule exists to stop.

## Check our own conformance before blaming the tool

When something appears to misbehave — Claude Code, a hook, the method itself —
read what the tool documents, then look for others reporting it, and only then
suspect the tool.

## File safety

```
staging    ->  name each path:  git add <path> <path>
pushing    ->  ask the user first, and push without --force
discarding ->  git stash, or git checkout -- <file>, or git reset HEAD~1
committing ->  check for secrets first
```

**Undoing a lot of work at once → read `${CLAUDE_PLUGIN_ROOT}/docs/recovery.md`
first.** Trigger: the user asks to roll the project back to an earlier state, or
a chat opens into the aftermath of one. Reference, fetched on demand.

**A clean `git status` means no UNCOMMITTED change**, so check recent commits
before reporting that an edit doesn't exist. A landed change and an absent one
look identical from a clean tree, and the difference matters most exactly when
the user is asking "did my change land?" — answered wrongly, they redo work that
already exists.

**Uncommitted changes you didn't make are the user's own work.** Read them as
expected handmade work, confirm with the user, and fold them into the close.

## Prior decisions

- Before raising a design question, run the throughline retrieve. If **the
  record** shows it's decided, state the prior decision. If the user revisits,
  flag when it was decided.

```
the record, in cheapest-first order:
    decisions recorded earlier in THIS chat      # no retrieve needed — you were there
    the item's own rationale in QUEUE.md         # where most decisions live until a close
    SPEC.md
    LOG/index.md, then the one matched entry
```

  **The source is the record, not LOG alone** — most decisions sit in QUEUE
  prose until a close. A question whose answer already follows from a decision
  made in this chat is not a new question, however differently it is framed;
  the test is against the decision's *reason*, not its wording.
- **Where an instruction points at a recorded plan by phrase — "as planned",
  "the way we agreed", "like last time" — read the record before acting.** The
  phrase names something written down; resolving it from memory or from what
  seems likely substitutes a guess for the thing the user was pointing at, and
  the guess is indistinguishable from the real plan until the work is done.
- **When the user proposes a change that would alter or reverse something the
  record already holds** — an existing rule, a shipped feature, a queued or
  logged decision — run the retrieve *before agreeing*, down the ladder above,
  and cite the prior decision rather than agreeing or pushing back generically.
  Trigger stays narrow to bound cost: fire only when the proposal touches
  something already in the record.
