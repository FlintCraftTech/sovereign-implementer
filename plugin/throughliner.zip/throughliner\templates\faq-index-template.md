# FAQ Index

Quick answers about how this project's workflow works. Each question links to a
full answer in [faq.md](faq.md). This FAQ fills as features are announced —
see the note at the top of faq.md — so a short list means little has been
announced yet, not that questions aren't welcome: just ask in chat.

- **How do I install Throughliner?** — the two routes in, and the paid plan you
  need. [faq.md](faq.md)
- **What happens in my first session?** — what `/setup` asks you, what it
  creates, and how a big project splits into parts later. [faq.md](faq.md)
- **What actually happens in a `/plan` session?** — captures, what gets cleared
  to run, and what the opening checks for. [faq.md](faq.md)
- **What does `/next` do?** — how a build run works, what stops it, and the
  three work tags. [faq.md](faq.md)
- **Why does every session end with `/done`, and why start a fresh chat?** —
  what the close records, and why the context window makes a fresh chat the
  next step. [faq.md](faq.md)
- **What is `/rescan` for?** — sweeping up what was said but never filed, and
  the two limits on how far back it reaches. [faq.md](faq.md)
- **Does `/plan` know what happened in my other sessions?** — the history it
  reads at the opening, the overlap it checks for, and why it reports either
  way. [faq.md](faq.md)
