---
name: done-build
docset: current
note: >
  Close-out for build-flavor work items. Reached from done.md's router for the
  run's build items (work items carrying no flavor tag).
---

# Build close-out

A build that changed SPEC.md — because a build item listed it as a large SPEC
rework — closes here like any other build. There is no separate spec-edit close.
A build cannot reach SPEC any other way: the grow-scope-and-edit-inline route is
repealed, and a build that finds SPEC owes a sentence files it instead.

```
a run may contain SEVERAL build items:
    per built item  ->  the judgment and record steps, one LOG entry each
    once per close  ->  the staleness sweep, the commit, the recommendation
```

## Phase 1: Judgment (while context is fresh)

Captures meaning that would be lost after compaction.

### Mid-close directive — new scope vs build-completing fix  [PROMPT]

If a new directive arises during the close — the user raises a change, or
verification turns one up — decide by one line: **does it complete the just-built
work's own verification, or is it new scope?**

```
a fix to a genuine bug in what this build was meant to deliver
    ->  FOLDS IN. Finish it, tick it — it's part of the build.
new scope (a redesign, a new feature, a change to something that already worked)
    ->  ROUTES OUT: a fresh /next, or a capture to Unprocessed if not urgent.
        Even if it looks small. Even if the user raises it here.
```

/done records and commits; it doesn't take on new build scope.

### 1.1 Verify completion  [SILENT] when every item is ticked; [PROMPT] when any is not

Read the build working file. Is every item ticked — each build item done?

```
yes             ->  proceed
some unticked   ->  [PROMPT] ask: finish the rest (/next), or close partial?
                    Wait for the user's call.
```

**Close partial by deleting the build working file and leaving the queue alone.**
An item is removed from QUEUE.md only as it is ticked, so an unticked item is
still sitting in Processed exactly where it was — there is no copy-back step and
no count to reconcile.

Before deleting the build working file, confirm the two halves agree: every
ticked item is gone from QUEUE.md, and every unticked one is still there. A
mismatch means an interruption landed between the tick and the removal — say
what you found and fix that one item, rather than proceeding.

**Reconcile against memory.** Where the session is still remembered, reconcile
the build working file against what you recall. If the file and memory disagree
— work that happened but went unticked, a Changes note missing something memory
knows was done — **that mismatch is itself a finding about build discipline**,
and it routes to Unprocessed per 1.2. It's the only routine check the build
working file's accuracy gets before a fresh session has to rely on it.

### 1.2 Route findings to Unprocessed  [PROMPT]

Each finding is written to Unprocessed first, then reported — the whole set as
one numbered report.

```
the RECORD this step sweeps:
    the build working file's notes
    any captures already appended at the moment of noticing
conversation memory  ->  a same-session BONUS pass, never a source the step
                         depends on
```

Append each finding to Unprocessed, placed per the Captures placement rule
(narrate the placement). Append any fix a build check surfaced too.

### 1.3 Spec check-against  [SILENT] when the run agrees with SPEC; [PROMPT] on a contradiction

**The build close checks the run's work against SPEC. It does not sync SPEC to
match it.** Each item was already checked as it was built (next-build.md, step 4);
this is the run-level look, over work that has accumulated.

```
run agrees with SPEC   ->  silent; nothing to report
run CONTRADICTS SPEC   ->  name the SPEC sentence and the work that contradicts
                           it, in plain words, and let the user decide which is
                           wrong. Do NOT rewrite SPEC to fit what was built.
```

**Where the build found that SPEC owes a sentence, it filed a capture and wrote
nothing** (next-build.md, Scope management). Confirm the capture exists and say
in one line that SPEC lags that sentence until the next planning run. **Do
not write it here:** the close is the same session as the build, so writing it
now moves the self-certification later rather than crossing the session boundary
the rule exists for.

This step exists for contradictions between the built work and SPEC as it
stands — a different thing from a sentence SPEC does not yet carry.

### 1.4 Red-flag close  [SILENT] when no flag; [PROMPT] when an item carries one

Per built item carrying a `Red flag · State: …` marker, before the item leaves
the queue. Its flag was cleared at an earlier /plan run, so two things:

```
1. carry the cleared flag into this item's LOG entry (2.1)
   # note it carried a red flag and that it was cleared. The substantive
   # how-it-cleared record was written at the /plan close that cleared it.
2. BACKSTOP [PROMPT]: marker still reads State: uncleared?
   # should be impossible. STOP and surface it rather than committing — an
   # uncleared flag at a ship close means the model was bypassed.
```

Silent when no built item carries a flag.

### 1.5 Reply to mail the run opened  [SILENT] when no mail arrived; [PROMPT] when it did

Where /next's pre-flight opened a message that asked a question, a reply is owed:
draft it now and show it. A defect report is owed nothing by default. The close is the moment the user is reliably present, which
mid-run is not — and a reply leaves the machine, so it goes out only on their
explicit yes to the exact wording, with the draft put in front of them unprompted.

## Phase 2: Record

### 2.1 Write LOG entry  [DISCUSS, PROMPT]

**Narrate first** [BRIEF]: one sentence noting the work's reasoning is being
carried from the build working file into the LOG entry — the file's last job before /done
deletes it.

Write **one LOG entry file per built item**, each named after that item's slug.
Follow done.md's **LOG entry files** section, with the build body fields:

```
Files touched       from the build working file Changes
Routed to Captures  items added, or "none"
```

**Read each built item's reasoning back, one entry at a time** [SILENT]. The run
built from the view, which carries instructions and no decision history, so the
*why* has not been in front of anyone since planning. This is where it reaches the
record.

**Read it from the queue as it stood before the run**, because the run has already
removed each item as it ticked:

```
git show HEAD:QUEUE.md
```

The run has not committed yet — the close is what commits — so every item this run
built is still in the last commit's copy, whole. **Take the item's whole block —
from its `#### ` heading to the next heading, or the section's end** — and
nothing else; a read of the whole file is what the view exists to avoid, and it
is not needed to answer one slug. A hand-sized grep or line window is not used:
a window shorter than the item once truncated the read twice in one close, and
both outputs reasoned from the cut-off text, one reaching the user.

**Where the fetched item's own text already dispositions a question the close is
about to put to the user, transcribe the disposition instead of asking** — and
an ask that deliberately re-opens one names the recorded decision it re-opens.

**Where QUEUE.md is untracked, git holds no copy and this route is closed.** Say
so plainly in the entry rather than implying the reasoning was carried: write the
entry from the working file's Changes and the item's own build block, and record
that the decision history could not be recovered. That is one of the consequences
of an untracked queue, and it is stated rather than discovered.

**One entry per built item is unconditional in COUNT, not in content**, however
long the run. A work item's queue text is *consumed* when it builds — /next
removes it — so after the build the LOG entry is the only surviving record of
what the work was for. The count rule never forbids done.md's sibling-citation
provision: where one decision settled several of the run's items, one entry
carries the reasoning and the sibling entries cite it, each still named for its
own slug. The close sees the grouping from what it already reads — each built
item's queue text, read back one at a time — so items whose text records the
same settlement are the siblings.

**Each item's depth field says which form its entry takes — read it, don't judge
it.** The field is defined at its authoring site, next.md's per-item completion
step, and is slug-bound: `Depth: <slug> — short|full`. Read each built item's
depth line **by its slug** rather than by its position under a tick, and
whatever the run's size — a twelve-item run can still contain the session's most
contested decision.

**A built slug with no depth line is read as short**, and noted at the close as
a discipline slip rather than passing silently: the field is required, so a
missing one means the build skipped a step, and saying so is what keeps it from
decaying back into an optional line.

**Transcribe each item's tick form into its LOG entry, and announce every
unconfirmed item at the close** [BRIEF]. The tick reads either `done, confirmed`
or `done, UNCONFIRMED: <what still needs running>` (next-build.md). Carry
whichever it says into the entry verbatim — transcribed, not composed — and where any item
is unconfirmed, say so plainly in the close's narration, naming the item and what
has not been run.

**The announcement is required rather than left to judgment.** `done-plan.md`'s
hold-back rule reads this field to decide whether dependent work may clear, so an
entry that omits it silently weakens a safety rule one document away.

**If a `[user]` item's entry was already started**, the walk-through opened it live
and appended as it went (next.md). Continue that file rather than writing a fresh
one — the existing entry is the record, not a duplicate.

If a built item carried a red flag, note in this entry that it carried one and
that it was cleared — the carry-through, since the substantive clearing record was
written at the /plan close that cleared it.

### 2.2 Staleness sweep  [SILENT] when clean; [BRIEF] when flagging

Run done.md's **Staleness sweep**.

### 2.3 Delete the build working file  [SILENT]

Routine bookkeeping — delete the file, no narration. Unlocks future builds. **Only
after everything above is complete.**

### 2.4 Commit

Run the commit core in done.md.

## Phase 3: Recommend next  [BRIEF, PROMPT]

Run done.md's **Recommend next** and apply its **Build close** delta: the shared
overlap scan + queue-state ladder are the whole recommendation.

**Leave the next run's size to the cleared-to-run line**, in the recommendation
and in the forward advisory alike. That line already *is* the run bound and the
user sets it at /plan; a second, softer cap downstream of it is a guess with no
measurement behind it, since Claude has no gauge of context filling at all.
Where a run genuinely needs to stop early, the no-progress halt is what stops
it — a behaviour-based stop rather than a number.
