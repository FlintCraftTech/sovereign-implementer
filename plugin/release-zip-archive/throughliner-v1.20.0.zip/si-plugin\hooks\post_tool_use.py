#!/usr/bin/env python3
"""
PostToolUse hook — advisory lint of QUEUE.md structure after edits.

Fires after Edit/Write/MultiEdit lands on the project's QUEUE.md. Reads
the file from disk and flags known format violations against the
two-section work-item model:

  1. A work item whose description heading doesn't end in a [slug]. A
     work item renders as a #### heading under ## Processed or
     ## Unprocessed; the slug at the end of that heading is what lets a
     later LOG entry name the work precisely.
  2. A missing section heading — both ## Processed and ## Unprocessed
     must be present. They are the two sections the whole model runs on.
  3. A red-flag marker line ("Red flag · State: ...") whose state isn't
     one of cleared / uncleared. A red flag is an ordinary work
     line carrying this one extra marker; the state must be valid.

Provenance is NOT linted. The old model required every work item to
carry a "captured by you" / "by Claude" label; that requirement is
gone. The convention is now asymmetric and default-AI: an unmarked item
is assumed to come from the AI, and an explicit "captured by you" credit
is written only when the user personally raised, pushed through, or
wrote the item. No AI-authorship label is ever written. Because a
user-credit is optional and an AI label is absent by design, there is
nothing to enforce — so the lint neither requires a label nor forbids
one (a leftover "by Claude" on an old item is harmless).

Deny-list by design: only known violations are flagged; unknown or
novel structure passes in silence, so the format can evolve (new
sections, new line shapes) without fighting the linter. All findings
are advisory — fed back to Claude as context next to the tool result,
never blocking: the edit has already landed, and judging whether a
flag is real stays with the session.
"""

import json
import os
import re
import sys


# A work item renders as a #### heading; its slug sits at the end of that
# heading line (processed and unprocessed work show this way, so the list
# — including anything below the cleared-to-run line — is navigable from
# an editor outline). The heading line is the work item's description line.
WORKLINE_HEADING = re.compile(r"^####\s+\S")

# The trailing [slug] on a work-item heading: lowercase kebab, two chars
# minimum, so a stray [x] tick or an [PROMPT]-style token never counts.
SLUG_AT_END = re.compile(r"\[[a-z0-9][a-z0-9-]+\]\s*$")

# A red-flag marker line: "Red flag · State: <state>". The middle dot is
# U+00B7 and is matched leniently (optional) so a spacing slip still reads
# as a marker and its state still gets validated.
RED_FLAG_MARKER = re.compile(r"^Red flag\s*·?\s*State:\s*(.*)$", re.IGNORECASE)

# The two sections the whole model runs on.
WORK_SECTIONS = ("Processed", "Unprocessed")

VALID_FLAG_STATES = {"cleared", "uncleared"}

# The single boundary /next runs on, and the shape of any structural
# `--- ... ---` line that legitimately sits between work items.
CLEARED_MARKER = "--- Cleared to run above this line ---"
STRUCTURAL_LINE = re.compile(r"^---\s.*---$")


def write_editing_marker(cwd: str, session_id: str, filepath: str, active: bool) -> None:
    """Clear the editing-state signal after a write. Never raises.

    The closing half of the heartbeat pre_tool_use starts: same file, same
    shape, `active` false and a fresh timestamp, keeping the last-written path
    so a reader can see which document was touched. Kept as a full rewrite
    rather than a patch of the existing file, so a marker left behind by a
    crashed session is replaced wholesale rather than merged with.

    The timestamp still leads on safety: even if this never runs — the session
    dies, the write is denied — the reader treats the stale marker as "not
    editing". Same never-fail rule as the pre-write half: any error here is
    swallowed, because a companion-app convenience must not be able to break
    the user's actual work.
    """
    try:
        import datetime

        marker_dir = os.path.join(cwd, ".throughliner")
        os.makedirs(marker_dir, exist_ok=True)
        safe_id = re.sub(r"[^A-Za-z0-9._-]", "_", session_id or "unknown")
        # Version-2 shape, kept field-for-field with pre_tool_use's opening
        # half: project-relative `files` (forward slashes, no leading "./",
        # absolute fallback for a file outside the project), `written_at` for
        # diagnosis-not-freshness, `producer` constant, pid/session dropped.
        # The version stamp and the path shape must move together — a marker
        # carrying version 2's relative paths under a version-1 stamp resolves
        # against the wrong root and holds nothing, with no error.
        if filepath:
            rel = os.path.relpath(os.path.abspath(filepath), cwd)
            marker_path = (
                os.path.abspath(filepath)
                if rel.startswith("..")
                else rel.replace(os.sep, "/")
            )
            files = [marker_path]
        else:
            files = []
        payload = {
            "version": 2,
            "active": bool(active),
            "written_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "files": files,
            "producer": "throughliner",
        }
        with open(
            os.path.join(marker_dir, f"editing-{safe_id}.json"), "w", encoding="utf-8"
        ) as f:
            json.dump(payload, f)
    except Exception:
        return


def _normalise(path: str) -> str:
    return os.path.normcase(os.path.normpath(path))


def _annotate(content: str):
    """Yield (index, stripped line, current h2, is_heading) per line.

    h2 is the nearest preceding `## ` heading (the section the line sits
    in); is_heading is true for any markdown heading line (`#`..`######`).
    """
    h2 = None
    out = []
    for i, raw in enumerate(content.splitlines()):
        stripped = raw.strip()
        is_heading = bool(re.match(r"#{1,6}\s", raw))
        if raw.startswith("## ") and not raw.startswith("### "):
            h2 = raw[3:].strip()
        out.append((i, stripped, h2, is_heading))
    return out


def _workline_blocks(annotated):
    """Group each #### work item under a work section with its own block.

    A block is the heading line plus every following line up to the next
    #### heading, the next heading of any level, or a section change. Lines
    outside the Processed/Unprocessed sections are ignored entirely, so a
    #### heading elsewhere in the file is never treated as a work item.
    """
    blocks = []
    current = None
    for i, line, h2, is_heading in annotated:
        if h2 not in WORK_SECTIONS:
            if current:
                blocks.append(current)
                current = None
            continue
        if WORKLINE_HEADING.match(line):
            if current:
                blocks.append(current)
            current = {"idx": i, "heading": line, "lines": [line]}
        elif is_heading:
            # Any other heading (a section change, a stray sub-heading) ends
            # the current work-item block.
            if current:
                blocks.append(current)
                current = None
        elif current is not None:
            current["lines"].append(line)
    if current:
        blocks.append(current)
    return blocks


def _check_slugs(blocks, warnings):
    """Check 1: every work-item heading ends in a [slug]."""
    for b in blocks:
        if not SLUG_AT_END.search(b["heading"]):
            warnings.append(
                f"line {b['idx'] + 1}: work item {b['heading'][:60]!r} has no "
                "[slug] at the end of its description line — every work item "
                "needs one so a later LOG entry can name it."
            )


def _check_sections(annotated, warnings):
    """Check 2: both ## Processed and ## Unprocessed headings are present."""
    present = {h2 for _i, _l, h2, _ih in annotated if h2}
    for name in WORK_SECTIONS:
        if name not in present:
            warnings.append(
                f"the '## {name}' section heading is missing — the queue holds "
                "two sections, Processed (discussed, kept work) and Unprocessed "
                "(captured, not yet fully processed)."
            )


def _check_red_flag_states(annotated, warnings):
    """Check 3: a red-flag marker line names a valid state.

    Scans every line, not only work-item blocks: a marker is only ever
    valid under a work item, but validating it wherever it appears is the
    fail-safe direction — a stray marker with a bad state still gets caught.
    """
    for i, line, _h2, _ih in annotated:
        match = RED_FLAG_MARKER.match(line)
        if not match:
            continue
        rest = match.group(1).strip()
        token = rest.split()[0].strip(".,;:—–-").lower() if rest else ""
        if token not in VALID_FLAG_STATES:
            shown = rest[:30] if rest else "(none)"
            warnings.append(
                f"line {i + 1}: red-flag marker has state {shown!r}, but a red "
                "flag's state must be one of cleared / uncleared."
            )


def _check_readiness_marker(annotated, blocks, warnings):
    """Check 4: exactly one readiness marker, in Processed, when work exists.

    The marker is the single boundary /next runs on, so its absence or
    duplication is a structural fault even though every item validates.
    Flagged, not repaired — advisory like the rest. The dangerous half of
    the failure (a missing marker silently clearing everything) is closed
    read-side in next.md, which now treats no-marker as nothing-cleared;
    this check is what makes the fault visible at the moment of the write.
    """
    marker_lines = [
        (i, h2) for i, line, h2, _ih in annotated if line == CLEARED_MARKER
    ]
    processed_has_items = any(
        h2 == "Processed" and WORKLINE_HEADING.match(line)
        for _i, line, h2, _ih in annotated
    )
    if len(marker_lines) > 1:
        lines_shown = ", ".join(str(i + 1) for i, _s in marker_lines)
        warnings.append(
            f"lines {lines_shown}: the cleared-to-run marker appears "
            f"{len(marker_lines)} times — there must be exactly one; /next "
            "runs on a single boundary and two markers make the run bound "
            "ambiguous."
        )
    elif not marker_lines and processed_has_items:
        warnings.append(
            "Processed holds work items but the '--- Cleared to run above "
            "this line ---' marker is missing — /next treats a missing "
            "marker as NOTHING cleared, so no work will run until the "
            "marker is restored."
        )
    for i, h2 in marker_lines:
        if h2 == "Unprocessed":
            warnings.append(
                f"line {i + 1}: the cleared-to-run marker sits in Unprocessed "
                "— it belongs in Processed, where it bounds what /next may "
                "run."
            )


def _check_orphaned_prose(annotated, warnings):
    """Check 5: every non-blank line in a work section belongs to a block.

    A line is orphaned when it sits inside Processed or Unprocessed with no
    #### heading above it (since the section started, or since a non-item
    heading ended the previous block). Structural `--- ... ---` marker lines
    are exempt, and so are blockquote lines (`> ...`): /setup scaffolds each
    work section's description paragraph as a blockquote immediately under the
    section heading — positionally identical to a destroyed first item's
    stranded rationale, so position cannot discriminate; form does. A stranded
    work-item rationale is never a blockquote. One flag per contiguous orphan
    run, so a destroyed heading yields one warning rather than one per
    rationale line.
    """
    in_block = False
    flagged_run = False
    for i, line, h2, is_heading in annotated:
        if h2 not in WORK_SECTIONS:
            in_block = False
            flagged_run = False
            continue
        if WORKLINE_HEADING.match(line):
            in_block = True
            flagged_run = False
            continue
        if is_heading:
            # A section heading or stray sub-heading ends any block.
            in_block = False
            flagged_run = False
            continue
        if not line or STRUCTURAL_LINE.match(line) or line.startswith(">"):
            flagged_run = False if not line else flagged_run
            continue
        if not in_block and not flagged_run:
            warnings.append(
                f"line {i + 1}: prose belongs to no work item — the text "
                f"starting {line[:50]!r} has no #### heading above it in this "
                "section. A destroyed or missing heading leaves an item's "
                "rationale orphaned like this; check whether an item's "
                "heading line was overwritten."
            )
            flagged_run = True


def lint(content: str) -> list[str]:
    annotated = _annotate(content)
    blocks = _workline_blocks(annotated)
    warnings = []
    _check_slugs(blocks, warnings)
    _check_sections(annotated, warnings)
    _check_red_flag_states(annotated, warnings)
    _check_readiness_marker(annotated, blocks, warnings)
    _check_orphaned_prose(annotated, warnings)
    return warnings


def main() -> int:
    try:
        data = json.load(sys.stdin)
    except (json.JSONDecodeError, OSError, ValueError):
        return 0

    if not isinstance(data, dict):
        return 0

    cwd = data.get("cwd", "")
    tool_name = data.get("tool_name", "")
    tool_input = data.get("tool_input") or {}

    if tool_name not in ("Edit", "Write", "MultiEdit"):
        return 0

    filepath = tool_input.get("file_path", "")
    if not filepath or not cwd:
        return 0

    is_adopted = os.path.isfile(os.path.join(cwd, "SPEC.md"))

    # Clear the editing-state signal for whatever file was just written —
    # every file, not only QUEUE.md, and before the QUEUE.md gate below.
    #
    # Gated on adoption to match pre_tool_use, which returns early with no
    # SPEC.md and so writes the OPENING marker only in adopted projects.
    # Without this the two hooks are asymmetric: an unadopted folder gets a
    # closing marker for a session that never opened one, so marker files
    # accumulate in projects that have nothing to do with this plugin — and
    # no .gitignore covers them, since /setup is what adds that entry and
    # those folders have never run it.
    if is_adopted:
        write_editing_marker(cwd, data.get("session_id", ""), filepath, False)

    # Only the project-root QUEUE.md, only in adopted projects.
    if _normalise(filepath) != _normalise(os.path.join(cwd, "QUEUE.md")):
        return 0
    if not is_adopted:
        return 0

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
    except (OSError, UnicodeDecodeError):
        return 0

    warnings = lint(content)
    if not warnings:
        return 0

    message = (
        "[Sovereign Implementer] QUEUE.md structure lint (advisory). "
        "These flag known violations only — novel structure is allowed "
        "and never flagged. Judge each one: fix what's genuinely wrong "
        "in a follow-up edit, leave what isn't.\n"
        + "\n".join(f"- {w}" for w in warnings)
    )
    output = {
        "hookSpecificOutput": {
            "hookEventName": "PostToolUse",
            "additionalContext": message,
        }
    }
    json.dump(output, sys.stdout)
    return 0


if __name__ == "__main__":
    sys.exit(main())
